/* Assignment 4
* Juanette van Wyk
* vanwykj@oregonstate.edu
* OSU: CS 492
*/

package com.example.cityreccomendations.model

class Category (
    val name: String,
    val recommendations: List<Recommendation>,
    val imageResId: Int
)